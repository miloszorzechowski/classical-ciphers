# classical-ciphers
Classes for encrypting and decrypting messages in classical ciphers. Supported ciphers:
- Morse Code
- Caesar Cipher
- Atbash Cipher